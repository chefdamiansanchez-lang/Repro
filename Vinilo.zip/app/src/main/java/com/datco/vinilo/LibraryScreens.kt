@file:OptIn(ExperimentalMaterial3Api::class)

package com.datco.vinilo

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.PlaylistAdd
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun NameDialog(title: String, initial: String = "", onConfirm: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                label = { Text("Nombre") }
            )
        },
        confirmButton = {
            TextButton(onClick = { if (text.isNotBlank()) onConfirm(text) }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun TrackRow(track: Track, onClick: () -> Unit, trailing: @Composable () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(start = 16.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(track.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 15.sp)
            Text(
                track.artist + "  ·  " + fmt(track.duration),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.secondary
            )
        }
        trailing()
    }
    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
}

@Composable
fun LibraryScreen(
    vm: PlayerViewModel,
    tab: Int,
    onTab: (Int) -> Unit,
    granted: Boolean,
    onRequest: () -> Unit,
    onOpenPlaylist: (Long) -> Unit,
    onBack: () -> Unit
) {
    var addTarget by remember { mutableStateOf<Track?>(null) }
    var newListFor by remember { mutableStateOf<Track?>(null) }
    var newList by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Biblioteca") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                    }
                }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { onTab(0) }, text = { Text("Canciones") })
                Tab(selected = tab == 1, onClick = { onTab(1) }, text = { Text("Listas") })
            }
            if (tab == 0) {
                if (!granted) {
                    Column(
                        Modifier.fillMaxSize().padding(24.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Necesito permiso para leer la música del teléfono.", textAlign = TextAlign.Center)
                        Spacer(Modifier.padding(8.dp))
                        Button(onClick = onRequest) { Text("Dar permiso") }
                    }
                } else if (vm.songs.isEmpty()) {
                    Text("No se encontraron canciones.", modifier = Modifier.padding(24.dp))
                } else {
                    LazyColumn(Modifier.fillMaxSize()) {
                        itemsIndexed(vm.songs, key = { _, t -> t.uri }) { i, t ->
                            TrackRow(
                                track = t,
                                onClick = {
                                    vm.playQueue(vm.songs, i)
                                    onBack()
                                }
                            ) {
                                IconButton(onClick = { addTarget = t }) {
                                    Icon(Icons.AutoMirrored.Filled.PlaylistAdd, contentDescription = "Agregar a lista")
                                }
                            }
                        }
                    }
                }
            } else {
                Column(Modifier.fillMaxSize()) {
                    Button(
                        onClick = { newList = true },
                        modifier = Modifier.fillMaxWidth().padding(12.dp)
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Nueva lista")
                    }
                    if (vm.playlists.isEmpty()) {
                        Text("Todavía no creaste listas.", modifier = Modifier.padding(24.dp))
                    }
                    LazyColumn(Modifier.fillMaxSize()) {
                        itemsIndexed(vm.playlists, key = { _, p -> p.id }) { _, p ->
                            Column(
                                Modifier
                                    .fillMaxWidth()
                                    .clickable { onOpenPlaylist(p.id) }
                                    .padding(horizontal = 16.dp, vertical = 12.dp)
                            ) {
                                Text(p.name, fontSize = 16.sp)
                                Text(
                                    "${p.tracks.size} canciones",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                            HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                        }
                    }
                }
            }
        }
    }

    addTarget?.let { track ->
        AlertDialog(
            onDismissRequest = { addTarget = null },
            title = { Text("Agregar a lista") },
            text = {
                Column {
                    if (vm.playlists.isEmpty()) Text("Todavía no tenés listas.")
                    vm.playlists.forEach { pl ->
                        TextButton(
                            onClick = {
                                vm.addToPlaylist(pl.id, track)
                                addTarget = null
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(pl.name) }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    newListFor = track
                    addTarget = null
                }) { Text("Nueva lista") }
            },
            dismissButton = { TextButton(onClick = { addTarget = null }) { Text("Cancelar") } }
        )
    }

    newListFor?.let { track ->
        NameDialog(
            title = "Nueva lista",
            onConfirm = { name ->
                val id = vm.createPlaylist(name)
                vm.addToPlaylist(id, track)
                newListFor = null
            },
            onDismiss = { newListFor = null }
        )
    }

    if (newList) {
        NameDialog(
            title = "Nueva lista",
            onConfirm = { name ->
                vm.createPlaylist(name)
                newList = false
            },
            onDismiss = { newList = false }
        )
    }
}

@Composable
fun PlaylistDetailScreen(vm: PlayerViewModel, id: Long, onBack: () -> Unit, onPlayed: () -> Unit) {
    val pl = vm.playlists.firstOrNull { it.id == id }
    LaunchedEffect(pl == null) { if (pl == null) onBack() }
    if (pl == null) return

    var rename by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(pl.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                    }
                },
                actions = {
                    IconButton(onClick = { rename = true }) {
                        Icon(Icons.Filled.Edit, contentDescription = "Renombrar")
                    }
                    IconButton(onClick = { confirmDelete = true }) {
                        Icon(Icons.Filled.Delete, contentDescription = "Eliminar lista")
                    }
                }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (pl.tracks.isEmpty()) {
                Text(
                    "Lista vacía. Agregá canciones desde la pestaña Canciones.",
                    modifier = Modifier.padding(24.dp)
                )
            } else {
                Button(
                    onClick = {
                        vm.playQueue(pl.tracks, 0)
                        onPlayed()
                    },
                    modifier = Modifier.fillMaxWidth().padding(12.dp)
                ) { Text("Reproducir lista") }
                LazyColumn(Modifier.fillMaxSize()) {
                    itemsIndexed(pl.tracks) { i, t ->
                        TrackRow(
                            track = t,
                            onClick = {
                                vm.playQueue(pl.tracks, i)
                                onPlayed()
                            }
                        ) {
                            IconButton(onClick = { vm.removeFromPlaylist(pl.id, i) }) {
                                Icon(Icons.Filled.Close, contentDescription = "Quitar")
                            }
                        }
                    }
                }
            }
        }
    }

    if (rename) {
        NameDialog(
            title = "Renombrar lista",
            initial = pl.name,
            onConfirm = {
                vm.renamePlaylist(pl.id, it)
                rename = false
            },
            onDismiss = { rename = false }
        )
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Eliminar lista") },
            text = { Text("¿Eliminar \"${pl.name}\"? Las canciones no se borran del teléfono.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    vm.deletePlaylist(pl.id)
                }) { Text("Eliminar") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancelar") } }
        )
    }
}
