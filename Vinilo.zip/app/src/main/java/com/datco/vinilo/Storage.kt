package com.datco.vinilo

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Track(val uri: String, val title: String, val artist: String, val duration: Long)

data class Playlist(val id: Long, val name: String, val tracks: List<Track> = emptyList())

class Storage(context: Context) {
    private val prefs = context.getSharedPreferences("vinilo_prefs", Context.MODE_PRIVATE)

    private fun tracksToJson(list: List<Track>): JSONArray {
        val arr = JSONArray()
        list.forEach { t ->
            arr.put(
                JSONObject()
                    .put("uri", t.uri)
                    .put("title", t.title)
                    .put("artist", t.artist)
                    .put("duration", t.duration)
            )
        }
        return arr
    }

    private fun jsonToTracks(arr: JSONArray): List<Track> =
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Track(o.getString("uri"), o.optString("title", ""), o.optString("artist", ""), o.optLong("duration", 0L))
        }

    // ---- Listas de reproducción (se guardan al instante) ----
    fun loadPlaylists(): List<Playlist> {
        val raw = prefs.getString("playlists", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Playlist(o.getLong("id"), o.getString("name"), jsonToTracks(o.getJSONArray("tracks")))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun savePlaylists(list: List<Playlist>) {
        val arr = JSONArray()
        list.forEach { p ->
            arr.put(
                JSONObject()
                    .put("id", p.id)
                    .put("name", p.name)
                    .put("tracks", tracksToJson(p.tracks))
            )
        }
        prefs.edit().putString("playlists", arr.toString()).commit()
    }

    // ---- Última cola de reproducción ----
    fun saveQueue(tracks: List<Track>) {
        prefs.edit().putString("queue", tracksToJson(tracks).toString()).apply()
    }

    fun loadQueue(): List<Track> = try {
        jsonToTracks(JSONArray(prefs.getString("queue", "[]")))
    } catch (e: Exception) {
        emptyList()
    }

    var queueIndex: Int
        get() = prefs.getInt("q_index", 0)
        set(value) { prefs.edit().putInt("q_index", value).apply() }

    var queuePos: Long
        get() = prefs.getLong("q_pos", 0L)
        set(value) { prefs.edit().putLong("q_pos", value).apply() }

    // ---- Ajustes de reproducción ----
    var volume: Float
        get() = prefs.getFloat("volume", 1f)
        set(value) { prefs.edit().putFloat("volume", value).apply() }

    var shuffle: Boolean
        get() = prefs.getBoolean("shuffle", false)
        set(value) { prefs.edit().putBoolean("shuffle", value).apply() }

    var repeatMode: Int
        get() = prefs.getInt("repeat", 0)
        set(value) { prefs.edit().putInt("repeat", value).apply() }

    // ---- Ecualizador ----
    var eqEnabled: Boolean
        get() = prefs.getBoolean("eq_on", true)
        set(value) { prefs.edit().putBoolean("eq_on", value).apply() }

    var eqLevels: List<Int>?
        get() = prefs.getString("eq_levels", null)?.split(",")?.mapNotNull { it.toIntOrNull() }
        set(value) { prefs.edit().putString("eq_levels", value?.joinToString(",")).apply() }

    var bass: Int
        get() = prefs.getInt("bass", 0)
        set(value) { prefs.edit().putInt("bass", value).apply() }

    var virt: Int
        get() = prefs.getInt("virt", 0)
        set(value) { prefs.edit().putInt("virt", value).apply() }
}
