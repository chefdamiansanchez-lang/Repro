package com.datco.vinilo

import android.app.Application
import android.content.ContentUris
import android.content.Intent
import android.os.Build
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.Player
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PlayerViewModel(app: Application) : AndroidViewModel(app) {
    private val player = PlayerHolder.player
    private val storage = PlayerHolder.storage
    val fx = PlayerHolder.effects

    var songs by mutableStateOf<List<Track>>(emptyList())
        private set
    var playlists by mutableStateOf(storage.loadPlaylists())
        private set

    var title by mutableStateOf("Elegí una canción")
        private set
    var artist by mutableStateOf("")
        private set
    var isPlaying by mutableStateOf(false)
        private set
    var shuffle by mutableStateOf(false)
        private set
    var repeatMode by mutableIntStateOf(Player.REPEAT_MODE_OFF)
        private set
    var position by mutableLongStateOf(0L)
        private set
    var duration by mutableLongStateOf(0L)
        private set
    var volume by mutableFloatStateOf(1f)
        private set

    var eqEnabled by mutableStateOf(storage.eqEnabled)
        private set
    var bass by mutableIntStateOf(storage.bass)
        private set
    var virt by mutableIntStateOf(storage.virt)
        private set
    val bandLevels = mutableStateListOf<Int>()

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            sync()
        }
    }

    init {
        player.addListener(listener)
        sync()
        initEq()
        viewModelScope.launch {
            while (true) {
                position = player.currentPosition.coerceAtLeast(0L)
                val d = player.duration
                if (d != C.TIME_UNSET) duration = d
                delay(400)
            }
        }
    }

    private fun sync() {
        isPlaying = player.isPlaying
        shuffle = player.shuffleModeEnabled
        repeatMode = player.repeatMode
        volume = player.volume
        val has = player.mediaItemCount > 0
        val md = player.mediaMetadata
        title = md.title?.toString() ?: if (has) "" else "Elegí una canción"
        artist = md.artist?.toString() ?: ""
        val d = player.duration
        duration = if (d == C.TIME_UNSET) 0L else d
        position = player.currentPosition.coerceAtLeast(0L)
    }

    // ---------- Biblioteca del dispositivo ----------
    fun loadSongs() {
        viewModelScope.launch {
            songs = withContext(Dispatchers.IO) { queryAudio() }
        }
    }

    private fun queryAudio(): List<Track> {
        val out = ArrayList<Track>()
        val collection = if (Build.VERSION.SDK_INT >= 29) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.DURATION
        )
        val selection = "${MediaStore.Audio.Media.IS_RINGTONE} = 0 AND " +
            "${MediaStore.Audio.Media.IS_NOTIFICATION} = 0 AND " +
            "${MediaStore.Audio.Media.IS_ALARM} = 0 AND " +
            "${MediaStore.Audio.Media.DURATION} >= 10000"
        try {
            getApplication<Application>().contentResolver.query(
                collection, projection, selection, null,
                "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
            )?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val iTitle = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val iArtist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val iDur = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                while (c.moveToNext()) {
                    val id = c.getLong(iId)
                    val art = c.getString(iArtist)?.takeIf { it != "<unknown>" } ?: "Artista desconocido"
                    out.add(
                        Track(
                            ContentUris.withAppendedId(collection, id).toString(),
                            c.getString(iTitle) ?: "Sin título",
                            art,
                            c.getLong(iDur)
                        )
                    )
                }
            }
        } catch (e: Exception) {
            // sin permiso o sin acceso: devuelve lo que haya
        }
        return out
    }

    // ---------- Reproducción ----------
    private fun startService() {
        try {
            val a = getApplication<Application>()
            a.startService(Intent(a, PlayerService::class.java))
        } catch (e: Exception) { }
    }

    fun playQueue(tracks: List<Track>, index: Int) {
        if (tracks.isEmpty()) return
        storage.saveQueue(tracks)
        player.setMediaItems(tracks.map { it.toMediaItem() }, index.coerceIn(0, tracks.size - 1), 0L)
        player.prepare()
        player.play()
        startService()
    }

    fun togglePlay() {
        if (player.mediaItemCount == 0) return
        if (player.isPlaying) {
            player.pause()
        } else {
            if (player.playbackState == Player.STATE_IDLE) player.prepare()
            if (player.playbackState == Player.STATE_ENDED) player.seekTo(0)
            player.play()
            startService()
        }
    }

    fun next() { player.seekToNext() }
    fun previous() { player.seekToPrevious() }
    fun seekTo(ms: Long) { player.seekTo(ms) }

    fun toggleShuffle() { player.shuffleModeEnabled = !player.shuffleModeEnabled }

    fun cycleRepeat() {
        player.repeatMode = when (player.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    fun changeVolume(v: Float) {
        player.volume = v
        volume = v
        storage.volume = v
    }

    // ---------- Listas de reproducción ----------
    private fun persist(list: List<Playlist>) {
        playlists = list
        storage.savePlaylists(list)
    }

    fun createPlaylist(name: String): Long {
        val id = System.currentTimeMillis()
        persist(playlists + Playlist(id, name.trim()))
        return id
    }

    fun renamePlaylist(id: Long, name: String) {
        persist(playlists.map { if (it.id == id) it.copy(name = name.trim()) else it })
    }

    fun deletePlaylist(id: Long) {
        persist(playlists.filterNot { it.id == id })
    }

    fun addToPlaylist(id: Long, track: Track) {
        persist(playlists.map {
            if (it.id == id && it.tracks.none { x -> x.uri == track.uri }) it.copy(tracks = it.tracks + track) else it
        })
    }

    fun removeFromPlaylist(id: Long, index: Int) {
        persist(playlists.map {
            if (it.id == id) it.copy(tracks = it.tracks.filterIndexed { i, _ -> i != index }) else it
        })
    }

    // ---------- Ecualizador ----------
    fun initEq() {
        bandLevels.clear()
        bandLevels.addAll(fx.levels())
    }

    fun toggleEq(on: Boolean) {
        eqEnabled = on
        fx.setEnabled(on)
    }

    fun setBand(index: Int, level: Int) {
        fx.setBand(index, level)
        if (index < bandLevels.size) bandLevels[index] = level
    }

    fun applyPreset(index: Int) {
        fx.usePreset(index)
        initEq()
    }

    fun updateBass(v: Int) {
        bass = v
        fx.setBass(v)
    }

    fun updateVirt(v: Int) {
        virt = v
        fx.setVirt(v)
    }

    override fun onCleared() {
        player.removeListener(listener)
        super.onCleared()
    }
}
