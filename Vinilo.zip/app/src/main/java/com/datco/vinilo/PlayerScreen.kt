@file:OptIn(ExperimentalMaterial3Api::class)

package com.datco.vinilo

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.SliderState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import kotlinx.coroutines.delay
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

private val Silver1 = Color(0xFFF6F6F6)
private val Silver2 = Color(0xFFC4C4C4)
private val KeyGray = Color(0xFF444444)

fun fmt(ms: Long): String {
    val s = ms.coerceAtLeast(0L) / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

private fun nowText(): String = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"))

@Composable
fun PlayerScreen(vm: PlayerViewModel, onLibrary: () -> Unit, onEq: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF14161B))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Display(vm, onEq, Modifier.weight(1f))
        ControlPanel(vm, onLibrary, onEq)
    }
}

@Composable
fun Display(vm: PlayerViewModel, onEq: () -> Unit, modifier: Modifier) {
    val clock by produceState(initialValue = nowText()) {
        while (true) {
            value = nowText()
            delay(1000)
        }
    }
    val progress = if (vm.duration > 0) vm.position.toFloat() / vm.duration.toFloat() else 0f

    Column(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Color.Black)
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = if (vm.artist.isBlank()) vm.title else "${vm.title} - ${vm.artist}",
                color = Color.White,
                fontFamily = FontFamily.Monospace,
                fontSize = 14.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(8.dp))
            Text(clock, color = Color(0xFF9DB7E8), fontFamily = FontFamily.Monospace, fontSize = 14.sp)
        }

        Turntable(
            isPlaying = vm.isPlaying,
            progress = progress,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        )

        Row(verticalAlignment = Alignment.CenterVertically) {
            Tag("EQ", vm.eqEnabled, onEq)
            Spacer(Modifier.width(8.dp))
            Tag("BASS", vm.bass > 0) { vm.updateBass(if (vm.bass > 0) 0 else 600) }
            Spacer(Modifier.width(8.dp))
            Tag("VIRT", vm.virt > 0) { vm.updateVirt(if (vm.virt > 0) 0 else 600) }
            Spacer(Modifier.weight(1f))
            Text(
                "VOLUMEN " + (vm.volume * 10).roundToInt().toString().padStart(2, '0'),
                color = Color(0xFFBBBBBB),
                fontSize = 12.sp
            )
        }

        var drag by remember { mutableStateOf<Float?>(null) }
        val max = if (vm.duration > 0) vm.duration.toFloat() else 1f
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(fmt(vm.position), color = Color.White, fontSize = 13.sp)
            Slider(
                value = (drag ?: vm.position.toFloat()).coerceIn(0f, max),
                onValueChange = { drag = it },
                onValueChangeFinished = {
                    drag?.let { vm.seekTo(it.toLong()) }
                    drag = null
                },
                valueRange = 0f..max,
                colors = SliderDefaults.colors(
                    thumbColor = Color.White,
                    activeTrackColor = Color(0xFFB7C7E8),
                    inactiveTrackColor = Color(0xFF333333)
                ),
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 6.dp)
            )
            Text(fmt(vm.duration), color = Color.White, fontSize = 13.sp)
        }
    }
}

@Composable
fun Tag(text: String, active: Boolean, onClick: () -> Unit) {
    val col = if (active) Color(0xFFFF3B30) else Color.White
    Box(
        modifier = Modifier
            .border(1.dp, if (active) col else Color(0xFF666666))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 4.dp)
    ) {
        Text(text, color = col, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

/** Plato giradiscos retro: LP girando y brazo que baja al reproducir. */
@Composable
fun Turntable(isPlaying: Boolean, progress: Float, modifier: Modifier = Modifier) {
    var angle by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            var last = androidx.compose.runtime.withFrameNanos { it }
            while (true) {
                val now = androidx.compose.runtime.withFrameNanos { it }
                angle = (angle + (now - last) / 1_000_000_000f * 200f) % 360f
                last = now
            }
        }
    }
    val swing by animateFloatAsState(if (isPlaying) 1f else 0f, tween(800), label = "arm")

    Canvas(modifier) {
        val s = minOf(size.width, size.height)
        translate((size.width - s) / 2f, (size.height - s) / 2f) {
            val c = Offset(s * 0.45f, s * 0.55f)
            val r = s * 0.40f

            drawCircle(color = Color(0xFF1C1C1C), radius = r * 1.04f, center = c)
            rotate(angle, c) {
                drawCircle(color = Color(0xFF0E0E0E), radius = r, center = c)
                var g = 0.42f
                while (g < 0.98f) {
                    drawCircle(color = Color(0xFF1F1F1F), radius = r * g, center = c, style = Stroke(width = 1.2f))
                    g += 0.035f
                }
                drawCircle(
                    brush = Brush.sweepGradient(
                        listOf(
                            Color.Transparent,
                            Color.White.copy(alpha = 0.14f),
                            Color.Transparent,
                            Color.Transparent,
                            Color.White.copy(alpha = 0.14f),
                            Color.Transparent
                        ),
                        center = c
                    ),
                    radius = r,
                    center = c
                )
                val lr = r * 0.36f
                drawCircle(color = Orange, radius = lr, center = c)
                drawCircle(color = Color(0xFFC9622A), radius = lr * 0.82f, center = c, style = Stroke(width = lr * 0.06f))
                for (k in 0 until 3) {
                    val a = (k * 120) * PI / 180.0
                    val rad = if (k == 0) lr * 0.1f else lr * 0.06f
                    drawCircle(
                        color = Color(0xFF7A3510),
                        radius = rad,
                        center = Offset(c.x + (lr * 0.55f * cos(a)).toFloat(), c.y + (lr * 0.55f * sin(a)).toFloat())
                    )
                }
                drawCircle(color = Color(0xFFF5E6C8), radius = lr * 0.22f, center = c)
                drawCircle(color = Color(0xFF111111), radius = lr * 0.06f, center = c)
            }

            // Brazo
            val pivot = Offset(s * 0.86f, s * 0.13f)
            val theta = -9f + swing * (23f + 12f * progress.coerceIn(0f, 1f))
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Color(0xFFEEEEEE), Color(0xFF8A8A8A)),
                    center = pivot,
                    radius = s * 0.075f
                ),
                radius = s * 0.075f,
                center = pivot
            )
            rotate(theta, pivot) {
                drawRoundRect(
                    color = Color(0xFF9A9A9A),
                    topLeft = Offset(pivot.x - s * 0.022f, pivot.y - s * 0.12f),
                    size = Size(s * 0.044f, s * 0.09f),
                    cornerRadius = CornerRadius(s * 0.01f)
                )
                drawLine(
                    color = Color(0xFFCFCFCF),
                    start = pivot,
                    end = Offset(pivot.x, pivot.y + s * 0.58f),
                    strokeWidth = s * 0.018f,
                    cap = StrokeCap.Round
                )
                drawRoundRect(
                    color = Color(0xFF2B2B2B),
                    topLeft = Offset(pivot.x - s * 0.03f, pivot.y + s * 0.56f),
                    size = Size(s * 0.06f, s * 0.085f),
                    cornerRadius = CornerRadius(s * 0.012f)
                )
            }
            drawCircle(color = Color(0xFF5A5A5A), radius = s * 0.03f, center = pivot)
        }
    }
}

@Composable
fun SilverButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(12.dp),
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .shadow(4.dp, shape)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Silver1, Silver2)))
            .border(1.dp, Color(0xFF9A9A9A), shape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
        content = content
    )
}

@Composable
fun FaderThumb() {
    val shape = RoundedCornerShape(6.dp)
    Box(
        Modifier
            .size(width = 26.dp, height = 40.dp)
            .shadow(3.dp, shape)
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(Color(0xFFBBBBBB), Color(0xFFFFFFFF), Color(0xFFBBBBBB))))
            .border(1.dp, Color(0xFF8A8A8A), shape)
    )
}

@Composable
fun FaderTrack(state: SliderState) {
    val range = state.valueRange
    val frac = ((state.value - range.start) / (range.endInclusive - range.start)).coerceIn(0f, 1f)
    Box(
        Modifier
            .fillMaxWidth()
            .height(6.dp)
            .clip(RoundedCornerShape(3.dp))
            .background(Color(0xFF111111))
    ) {
        Box(
            Modifier
                .fillMaxWidth(frac)
                .fillMaxHeight()
                .background(Color(0xFFD32F2F))
        )
    }
}

@Composable
fun ControlPanel(vm: PlayerViewModel, onLibrary: () -> Unit, onEq: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFFE9E9E9), Color(0xFFBEBEBE))))
            .padding(12.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            SilverButton(onLibrary, Modifier.weight(1f).height(48.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.AutoMirrored.Filled.QueueMusic, contentDescription = "Listas", tint = KeyGray)
                    Spacer(Modifier.width(6.dp))
                    Text("LISTAS", color = KeyGray, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
            SilverButton(onEq, Modifier.weight(1f).height(48.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Equalizer, contentDescription = "Ecualizador", tint = KeyGray)
                    Spacer(Modifier.width(6.dp))
                    Text("EQ", color = KeyGray, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        Text(
            "VOLUMEN",
            color = KeyGray,
            fontSize = 12.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
        Slider(
            value = vm.volume,
            onValueChange = { vm.changeVolume(it) },
            valueRange = 0f..1f,
            thumb = { FaderThumb() },
            track = { FaderTrack(it) },
            modifier = Modifier.padding(horizontal = 8.dp)
        )

        Spacer(Modifier.height(6.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            SilverButton({ vm.cycleRepeat() }, Modifier.size(44.dp)) {
                Icon(
                    if (vm.repeatMode == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                    contentDescription = "Repetir",
                    tint = if (vm.repeatMode == Player.REPEAT_MODE_OFF) KeyGray else Orange
                )
            }
            SilverButton({ vm.previous() }, Modifier.size(56.dp), CircleShape) {
                Icon(Icons.Filled.SkipPrevious, contentDescription = "Anterior", tint = KeyGray, modifier = Modifier.size(30.dp))
            }
            SilverButton({ vm.togglePlay() }, Modifier.size(76.dp), CircleShape) {
                Icon(
                    if (vm.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = "Reproducir o pausar",
                    tint = KeyGray,
                    modifier = Modifier.size(42.dp)
                )
            }
            SilverButton({ vm.next() }, Modifier.size(56.dp), CircleShape) {
                Icon(Icons.Filled.SkipNext, contentDescription = "Siguiente", tint = KeyGray, modifier = Modifier.size(30.dp))
            }
            SilverButton({ vm.toggleShuffle() }, Modifier.size(44.dp)) {
                Icon(
                    Icons.Filled.Shuffle,
                    contentDescription = "Aleatorio",
                    tint = if (vm.shuffle) Orange else KeyGray
                )
            }
        }
    }
}
