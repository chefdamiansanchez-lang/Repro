package com.datco.vinilo

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer

class Effects(private val st: Storage) {
    private var eq: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null

    val available: Boolean get() = eq != null
    val bandCount: Int get() = eq?.numberOfBands?.toInt() ?: 0
    val minLevel: Int get() = eq?.bandLevelRange?.get(0)?.toInt() ?: -1500
    val maxLevel: Int get() = eq?.bandLevelRange?.get(1)?.toInt() ?: 1500

    fun freqHz(band: Int): Int = (eq?.getCenterFreq(band.toShort()) ?: 0) / 1000

    fun presetNames(): List<String> {
        val e = eq ?: return emptyList()
        return (0 until e.numberOfPresets.toInt()).map { e.getPresetName(it.toShort()) }
    }

    fun levels(): List<Int> {
        val e = eq ?: return emptyList()
        return (0 until bandCount).map { e.getBandLevel(it.toShort()).toInt() }
    }

    @Synchronized
    fun attach(session: Int) {
        release()
        if (session <= 0) return
        try {
            val e = Equalizer(0, session)
            val lo = e.bandLevelRange[0].toInt()
            val hi = e.bandLevelRange[1].toInt()
            val saved = st.eqLevels
            if (saved != null && saved.size == e.numberOfBands.toInt()) {
                saved.forEachIndexed { i, l -> e.setBandLevel(i.toShort(), l.coerceIn(lo, hi).toShort()) }
            }
            e.enabled = st.eqEnabled
            eq = e
        } catch (ex: Exception) {
            eq = null
        }
        try {
            val b = BassBoost(0, session)
            if (b.strengthSupported) b.setStrength(st.bass.toShort())
            b.enabled = st.bass > 0
            bassBoost = b
        } catch (ex: Exception) {
            bassBoost = null
        }
        try {
            val v = Virtualizer(0, session)
            if (v.strengthSupported) v.setStrength(st.virt.toShort())
            v.enabled = st.virt > 0
            virtualizer = v
        } catch (ex: Exception) {
            virtualizer = null
        }
    }

    fun release() {
        try { eq?.release() } catch (e: Exception) { }
        try { bassBoost?.release() } catch (e: Exception) { }
        try { virtualizer?.release() } catch (e: Exception) { }
        eq = null
        bassBoost = null
        virtualizer = null
    }

    fun setEnabled(on: Boolean) {
        st.eqEnabled = on
        try { eq?.enabled = on } catch (e: Exception) { }
    }

    fun setBand(band: Int, level: Int) {
        try { eq?.setBandLevel(band.toShort(), level.toShort()) } catch (e: Exception) { }
        st.eqLevels = levels()
    }

    fun usePreset(index: Int) {
        try { eq?.usePreset(index.toShort()) } catch (e: Exception) { }
        st.eqLevels = levels()
    }

    fun setBass(value: Int) {
        st.bass = value
        try {
            bassBoost?.let {
                if (it.strengthSupported) it.setStrength(value.toShort())
                it.enabled = value > 0
            }
        } catch (e: Exception) { }
    }

    fun setVirt(value: Int) {
        st.virt = value
        try {
            virtualizer?.let {
                if (it.strengthSupported) it.setStrength(value.toShort())
                it.enabled = value > 0
            }
        } catch (e: Exception) { }
    }
}
