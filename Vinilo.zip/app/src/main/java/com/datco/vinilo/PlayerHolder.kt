package com.datco.vinilo

import android.app.Application
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

fun Track.toMediaItem(): MediaItem =
    MediaItem.Builder()
        .setMediaId(uri)
        .setUri(uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .build()
        )
        .build()

/** Reproductor único compartido por la pantalla, el servicio en segundo plano y el widget. */
object PlayerHolder {
    lateinit var app: Application
    lateinit var player: ExoPlayer
    lateinit var storage: Storage
    lateinit var effects: Effects

    val isReady: Boolean get() = ::player.isInitialized

    fun init(application: Application) {
        if (isReady) return
        app = application
        storage = Storage(app)
        player = ExoPlayer.Builder(app)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        effects = Effects(storage)
        effects.attach(player.audioSessionId)
        player.volume = storage.volume
        player.shuffleModeEnabled = storage.shuffle
        player.repeatMode = storage.repeatMode
        restoreQueue()

        player.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                effects.attach(audioSessionId)
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                saveProgress()
                ViniloWidget.update(app)
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                saveProgress()
                ViniloWidget.update(app)
            }

            override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
                ViniloWidget.update(app)
            }

            override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
                storage.shuffle = shuffleModeEnabled
            }

            override fun onRepeatModeChanged(repeatMode: Int) {
                storage.repeatMode = repeatMode
            }

            override fun onPlayerError(error: PlaybackException) {
                // Si un archivo ya no existe o falla, pasa al siguiente
                if (player.hasNextMediaItem()) {
                    player.seekToNextMediaItem()
                    player.prepare()
                }
            }
        })
    }

    private fun restoreQueue() {
        val q = storage.loadQueue()
        if (q.isEmpty()) return
        val idx = storage.queueIndex.coerceIn(0, q.size - 1)
        player.setMediaItems(q.map { it.toMediaItem() }, idx, storage.queuePos)
        player.prepare()
    }

    fun saveProgress() {
        if (!isReady) return
        if (player.mediaItemCount > 0) {
            storage.queueIndex = player.currentMediaItemIndex
            storage.queuePos = player.currentPosition.coerceAtLeast(0L)
        }
    }
}
