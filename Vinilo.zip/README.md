# Vinilo - Reproductor de música (DATCO)

App Android (Kotlin + Jetpack Compose + Media3).

- Toca mp3, wav, flac, ogg, m4a/aac, opus y más del teléfono
- LP retro con brazo animado, ecualizador, Bass y Virtualizador
- Listas de reproducción que quedan guardadas
- Sigue sonando en segundo plano (notificación + pantalla de bloqueo)
- Widget con anterior / play-pausa / siguiente
- Splash de DATCO al abrir

## Compilar en GitHub
1. Subí este zip a un repositorio nuevo.
2. Pestaña Actions -> "Compilar APK Vinilo" -> Run workflow (o se ejecuta solo al subir).
3. Al terminar, abrí la ejecución y descargá "Vinilo-APK" (dentro hay app-debug.apk).
